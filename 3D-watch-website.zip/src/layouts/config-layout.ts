// ----------------------------------------------------------------------

export const HEADER = {
  H_MOBILE: 34,
  H_DESKTOP: 60,
  H_DESKTOP_OFFSET: 80 - 16,
};

export const NAV = {
  W_VERTICAL: 280,
  W_MINI: 88,
};
